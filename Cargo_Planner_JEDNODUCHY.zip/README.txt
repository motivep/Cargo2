CARGO PLANNER – JEDNODUCHÁ VERZE

Tato verze je záměrně jednoduchá:
- zadáš délku a šířku nakládací plochy
- přidáš druhy nákladu, rozměry a počty kusů
- aplikace hledá rozložení, aby se vešlo co nejvíce kusů
- může povolit otočení kusů
- bez hmotnosti, náprav, těžiště a výšky

Pro GitHub Pages nahraj obsah této složky tak, aby index.html byl přímo v kořenu repozitáře.
